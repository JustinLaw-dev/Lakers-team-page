--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE basketball;
--
-- Name: basketball; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE basketball WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United States.1252' LC_CTYPE = 'English_United States.1252';


ALTER DATABASE basketball OWNER TO postgres;

\connect basketball

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: anthony_davis; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.anthony_davis (
    r integer NOT NULL,
    g integer,
    age character varying(50),
    team character varying(50),
    at character varying(10),
    opp character varying(50),
    w_l character varying(50),
    gs character varying(50),
    mp character varying(100),
    fg integer,
    fga integer,
    fg_percent numeric,
    three_pt integer,
    three_pt_a integer,
    three_pt_perc numeric,
    ft integer,
    fta integer,
    ft_percent numeric,
    orb integer,
    drb integer,
    trb integer,
    ast integer,
    stl integer,
    blk integer,
    tov integer,
    pf integer,
    pts integer,
    gmsc character varying(25),
    plus_minus integer
);


ALTER TABLE public.anthony_davis OWNER TO postgres;

--
-- Name: kyle_kuzma; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kyle_kuzma (
    r integer NOT NULL,
    g integer,
    age character varying(50),
    team character varying(50),
    at character varying(10),
    opp character varying(50),
    w_l character varying(50),
    gs character varying(50),
    mp character varying(100),
    fg integer,
    fga integer,
    fg_percent numeric,
    three_pt integer,
    three_pt_a integer,
    three_pt_perc numeric,
    ft integer,
    fta integer,
    ft_percent numeric,
    orb integer,
    drb integer,
    trb integer,
    ast integer,
    stl integer,
    blk integer,
    tov integer,
    pf integer,
    pts integer,
    gmsc character varying(25),
    plus_minus integer
);


ALTER TABLE public.kyle_kuzma OWNER TO postgres;

--
-- Name: lebron_james; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lebron_james (
    r integer NOT NULL,
    g integer,
    age character varying(50),
    team character varying(50),
    at character varying(10),
    opp character varying(50),
    w_l character varying(50),
    gs character varying(50),
    mp character varying(100),
    fg integer,
    fga integer,
    fg_percent numeric,
    three_pt integer,
    three_pt_a integer,
    three_pt_perc numeric,
    ft integer,
    fta integer,
    ft_percent numeric,
    orb integer,
    drb integer,
    trb integer,
    ast integer,
    stl integer,
    blk integer,
    tov integer,
    pf integer,
    pts integer,
    gmsc character varying(25),
    plus_minus integer
);


ALTER TABLE public.lebron_james OWNER TO postgres;

--
-- Data for Name: anthony_davis; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.anthony_davis (r, g, age, team, at, opp, w_l, gs, mp, fg, fga, fg_percent, three_pt, three_pt_a, three_pt_perc, ft, fta, ft_percent, orb, drb, trb, ast, stl, blk, tov, pf, pts, gmsc, plus_minus) FROM stdin;
\.
COPY public.anthony_davis (r, g, age, team, at, opp, w_l, gs, mp, fg, fga, fg_percent, three_pt, three_pt_a, three_pt_perc, ft, fta, ft_percent, orb, drb, trb, ast, stl, blk, tov, pf, pts, gmsc, plus_minus) FROM '$$PATH$$/2828.dat';

--
-- Data for Name: kyle_kuzma; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kyle_kuzma (r, g, age, team, at, opp, w_l, gs, mp, fg, fga, fg_percent, three_pt, three_pt_a, three_pt_perc, ft, fta, ft_percent, orb, drb, trb, ast, stl, blk, tov, pf, pts, gmsc, plus_minus) FROM stdin;
\.
COPY public.kyle_kuzma (r, g, age, team, at, opp, w_l, gs, mp, fg, fga, fg_percent, three_pt, three_pt_a, three_pt_perc, ft, fta, ft_percent, orb, drb, trb, ast, stl, blk, tov, pf, pts, gmsc, plus_minus) FROM '$$PATH$$/2829.dat';

--
-- Data for Name: lebron_james; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lebron_james (r, g, age, team, at, opp, w_l, gs, mp, fg, fga, fg_percent, three_pt, three_pt_a, three_pt_perc, ft, fta, ft_percent, orb, drb, trb, ast, stl, blk, tov, pf, pts, gmsc, plus_minus) FROM stdin;
\.
COPY public.lebron_james (r, g, age, team, at, opp, w_l, gs, mp, fg, fga, fg_percent, three_pt, three_pt_a, three_pt_perc, ft, fta, ft_percent, orb, drb, trb, ast, stl, blk, tov, pf, pts, gmsc, plus_minus) FROM '$$PATH$$/2830.dat';

--
-- Name: anthony_davis anthony_davis_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.anthony_davis
    ADD CONSTRAINT anthony_davis_pkey PRIMARY KEY (r);


--
-- Name: kyle_kuzma kyle_kuzma_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kyle_kuzma
    ADD CONSTRAINT kyle_kuzma_pkey PRIMARY KEY (r);


--
-- Name: lebron_james lebron_james_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lebron_james
    ADD CONSTRAINT lebron_james_pkey PRIMARY KEY (r);


--
-- PostgreSQL database dump complete
--

